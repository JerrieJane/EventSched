<?php include('dbconnect.php'); 
	//fetch the record to be update
	if (isset($_GET['edit'])) {
		$id = $_GET['edit'];
		$edit_state=true;
		$rec =mysqli_query($mydb, "SELECT * FROM information WHERE id=$id");
		$record = mysqli_fetch($rec);
		$event = $record['event'];
		$location = $record['location'];
		$date1 = $record['date1'];
		$time1 = $record['time1'];
		$id = $record['id'];
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Event Scheduler</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

	<?php if (isset($_SESSION['msg'])): ?>
		<div class="msg">
			<?php
				echo $_SESSION['msg'];
				unset($_SESSION['msg']); 
			?>
		</div>
	<table>
		<thead>
			<tr> 
				<th>Event</th>
				<th>Location</th>
				<th>Date</th>
				<th>Time</th>
				<th colspan="2">Action</th>
			</tr>
		</thead>
		<tbody>
			<?php while ($row = mysqli_fetch_array($results)) { ?>
				<tr>
					<td><?php echo $row['event']; ?></td>
					<td><?php echo $row['location']; ?></td>
					<td><?php echo $row['date1']; ?></td>
					<td><?php echo $row['time1']; ?></td>  
					<td>
						<a class="edit_btn" href="#index.php? edit=<?php echo $row['id']; ?>">Edit</a>
					</td>
					<td>
						<a class="del_btn" href="server.php?del=<?php echo $row['id']; ?>">Delete</a>
					</td>
				</tr>	
			<?php } ?>
			
		</tbody>
	</table>

	<form method="post" action="dbconnect.php">
	<input type="hidden" name="id" value="<?php echo $id; ?>">
		<div class="input-group">
			<label>Event</label>
			<input type="text" name="event" value="<?php echo $name; ?>">
		</div>
		<div class="input-group">
			<label>Location</label>
			<input type="text" name="location" value="<?php echo $location; ?>">
		</div>
		<div class="input-group">
			<label>Date</label>
			<input type="text" name="date1" value="<?php echo $date1; ?>">
		</div>
		<div class="input-group">
			<label>Time</label>
			<input type="text" name="time1" value="<?php echo $time1; ?>">
		</div>
		<div class="input-group">
		<?php if ($edit_state == false): ?>
			<button type="submit" name="save" class="btn">Save</button>
		<?php else: ?>
			<button type="submit" name="update" class="btn">Update</button>
		<?php endif ?>
			
		</div>
	</form>
</body>
</html> 