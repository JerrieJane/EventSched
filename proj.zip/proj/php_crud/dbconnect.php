<?php
	session_start();
	// this is to initialize variables
	$event = "";
	$location = "";
	$date = "";
	$time = "";
	$id = 0;
	$update_state= false; 
	//connect to databse
	$mydb =mysqli_connect('localhost','root','','event_scheduler');

	// save button
	if (isset($_POST['save'])) {
		$event =$_POST['event']; 
		$location =$_POST['location'];
		$date =$_POST['date1'];
		$time =$_POST['time1'];

		$query = "INSERT INTO information (event,location,date1,time1) VALUES ('$event','$location','$date','$time')";
		mysqli_query ($mydb,$query);
		
		header('location: index.php');//redirect to index page after inserting
	}

	//update records 
	if (isset($_POST['update'])){
		$event = mysql_real_escape_string($_POST['event']);
		$location = mysql_real_escape_string($_POST['location']);
		$date1 = mysql_real_escape_string($_POST['date1']);
		$time1 = mysql_real_escape_string($_POST['time1']);
		$id = mysql_real_escape_string($_POST['id']);

		mysqli_query($mydb,"UPDATE information SET event='$event', location='$location', date1='$date1', time1='$time1' WHERE id=$id")
		
	} 
 	//delete records
 	if (isset($GET['del'])) {
		$id = $GET['del'];
		mysqli_query($mydb, "DELETE FROM information WHERE id=$id");
		$_SESSION['mg'] = "Location delete";
		header('location: index.php');
 	}

	//retrive records
	$results = myqli_query($mydb,"SELECT * FROM info");
?> 